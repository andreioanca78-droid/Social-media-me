package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.MediaType
import com.example.data.model.NotificationType

class Converters {
    @TypeConverter
    fun fromStringList(value: List<String>?): String {
        return value?.joinToString(";;;") ?: ""
    }

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return value.split(";;;").filter { it.isNotBlank() }
    }

    @TypeConverter
    fun fromMediaType(value: MediaType?): String {
        return value?.name ?: MediaType.PHOTO.name
    }

    @TypeConverter
    fun toMediaType(value: String?): MediaType {
        return try {
            if (value != null) MediaType.valueOf(value) else MediaType.PHOTO
        } catch (e: Exception) {
            MediaType.PHOTO
        }
    }

    @TypeConverter
    fun fromNotificationType(value: NotificationType?): String {
        return value?.name ?: NotificationType.LIKE.name
    }

    @TypeConverter
    fun toNotificationType(value: String?): NotificationType {
        return try {
            if (value != null) NotificationType.valueOf(value) else NotificationType.LIKE
        } catch (e: Exception) {
            NotificationType.LIKE
        }
    }
}
