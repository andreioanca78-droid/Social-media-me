package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AppNotification
import com.example.data.model.Comment
import com.example.data.model.FollowRelation
import com.example.data.model.MediaType
import com.example.data.model.NotificationType
import com.example.data.model.PostBookmark
import com.example.data.model.PostItem
import com.example.data.model.PostLike
import com.example.data.model.UserAccount
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserAccount::class,
        PostItem::class,
        FollowRelation::class,
        PostLike::class,
        PostBookmark::class,
        Comment::class,
        AppNotification::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao
    abstract fun socialDao(): SocialDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pulse_social.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(db: AppDatabase) {
                val userDao = db.userDao()
                val postDao = db.postDao()
                val socialDao = db.socialDao()

                // Initial Seed Users
                val mainUser = UserAccount(
                    id = "usr_current",
                    username = "jordan_sky",
                    displayName = "Jordan Sky",
                    bio = "Visual storyteller, drone pilot & tech enthusiast 🌌 Living between frames.",
                    avatarRes = "avatar_user",
                    coverRes = "cover_user",
                    interests = listOf("Photography", "Cinematic", "Tech", "Travel"),
                    followerCount = 428,
                    followingCount = 3,
                    postCount = 1,
                    isVerified = true
                )

                val creatorNature = UserAccount(
                    id = "usr_nature",
                    username = "elena_wild",
                    displayName = "Elena Rostova",
                    bio = "National Parks explorer & 4K landscape filmmaker. Chasing mist & alpine light 🌲🏔️",
                    avatarRes = "avatar_nature",
                    coverRes = "cover_nature",
                    interests = listOf("Nature", "Photography", "Travel", "Cinematic"),
                    followerCount = 18420,
                    followingCount = 129,
                    postCount = 48,
                    isVerified = true
                )

                val creatorTech = UserAccount(
                    id = "usr_tech",
                    username = "marcus_dev",
                    displayName = "Marcus Vance",
                    bio = "Hardware hacker, UI/UX craftsman & future tech reviewer. Dark mode always ⚡🖥️",
                    avatarRes = "avatar_tech",
                    coverRes = "cover_tech",
                    interests = listOf("Tech", "Design", "Gaming"),
                    followerCount = 9310,
                    followingCount = 210,
                    postCount = 35,
                    isVerified = true
                )

                val creatorUrban = UserAccount(
                    id = "usr_urban",
                    username = "kai_cyber",
                    displayName = "Kai Tanaka",
                    bio = "Tokyo night wanderer. Rain reflections, neon aesthetic & street cinematography 🌃🌧️",
                    avatarRes = "avatar_urban",
                    coverRes = "cover_urban",
                    interests = listOf("Cinematic", "Photography", "Travel", "Art"),
                    followerCount = 24100,
                    followingCount = 88,
                    postCount = 62,
                    isVerified = true
                )

                val creatorArt = UserAccount(
                    id = "usr_art",
                    username = "maya_motion",
                    displayName = "Maya Chen",
                    bio = "3D animator & generative visual artist. Creating digital dreamscapes ✨🎨",
                    avatarRes = "avatar_art",
                    coverRes = "cover_art",
                    interests = listOf("Art", "Design", "Tech", "Cinematic"),
                    followerCount = 12500,
                    followingCount = 95,
                    postCount = 29,
                    isVerified = true
                )

                val seedUsers = listOf(mainUser, creatorNature, creatorTech, creatorUrban, creatorArt)
                userDao.insertUsers(seedUsers)

                // Follow some creators initially so Following feed has posts
                socialDao.insertFollow(FollowRelation(followerId = "usr_current", followedId = "usr_nature"))
                socialDao.insertFollow(FollowRelation(followerId = "usr_current", followedId = "usr_urban"))
                socialDao.insertFollow(FollowRelation(followerId = "usr_current", followedId = "usr_tech"))

                // Initial Seed Posts (Photos and Videos with rich titles, descriptions, hashtags)
                val post1 = PostItem(
                    id = "post_nature_video_1",
                    userId = "usr_nature",
                    mediaType = MediaType.VIDEO,
                    mediaRes = "img_nature_thumb",
                    thumbnailUrl = "",
                    videoDurationSeconds = 24,
                    title = "Sunrise Over Emerald Peaks 4K Drone Flight",
                    description = "Woke up at 4:30 AM to catch the fog rolling across the alpine ridge. The morning light hitting the pine canopy was pure magic! Shot on 6K anamorphic. #drone #alpine #nature #cinematic #sunrise #wild",
                    category = "Nature",
                    tags = listOf("drone", "alpine", "nature", "cinematic", "sunrise"),
                    location = "Banff National Park, Canada",
                    likeCount = 1420,
                    commentCount = 68,
                    shareCount = 192,
                    viewCount = 8900,
                    createdAt = System.currentTimeMillis() - 1000 * 60 * 45 // 45 mins ago
                )

                val post2 = PostItem(
                    id = "post_urban_photo_1",
                    userId = "usr_urban",
                    mediaType = MediaType.PHOTO,
                    mediaRes = "img_urban_thumb",
                    thumbnailUrl = "",
                    videoDurationSeconds = 0,
                    title = "Shinjuku Rain Symphony - Neon Reflections",
                    description = "Heavy monsoon rain transformed the alleyway into a glowing mirror of neon signs. There is a quiet stillness in rainy Tokyo nights. #tokyo #streetphotography #cyberpunk #neon #reflection",
                    category = "Photography",
                    tags = listOf("tokyo", "streetphotography", "cyberpunk", "neon"),
                    location = "Shinjuku, Tokyo, Japan",
                    likeCount = 2890,
                    commentCount = 142,
                    shareCount = 410,
                    viewCount = 15300,
                    createdAt = System.currentTimeMillis() - 1000 * 60 * 180 // 3 hours ago
                )

                val post3 = PostItem(
                    id = "post_tech_video_1",
                    userId = "usr_tech",
                    mediaType = MediaType.VIDEO,
                    mediaRes = "img_tech_thumb",
                    thumbnailUrl = "",
                    videoDurationSeconds = 18,
                    title = "The Minimalist 2026 Developer Desk Tour & Glow",
                    description = "Custom 65% mechanical board with hand-lubed switches, ambient warm backlight, and clean cable routing. Productivity increased by 200%. #desksetup #workspace #developer #tech #aesthetic",
                    category = "Tech",
                    tags = listOf("desksetup", "workspace", "developer", "tech"),
                    location = "San Francisco, CA",
                    likeCount = 985,
                    commentCount = 53,
                    shareCount = 88,
                    viewCount = 6400,
                    createdAt = System.currentTimeMillis() - 1000 * 60 * 360 // 6 hours ago
                )

                val post4 = PostItem(
                    id = "post_user_photo_1",
                    userId = "usr_current",
                    mediaType = MediaType.PHOTO,
                    mediaRes = "img_nature_thumb",
                    thumbnailUrl = "",
                    videoDurationSeconds = 0,
                    title = "First Light in the Valley",
                    description = "Testing out my new telephoto lens during the dawn golden hour. Absolutely thrilled with the sharpness and color rendition! #photography #nature #morningglow #telephoto",
                    category = "Photography",
                    tags = listOf("photography", "nature", "morningglow"),
                    location = "Cascade Range, WA",
                    likeCount = 312,
                    commentCount = 19,
                    shareCount = 24,
                    viewCount = 1890,
                    createdAt = System.currentTimeMillis() - 1000 * 60 * 720 // 12 hours ago
                )

                val post5 = PostItem(
                    id = "post_art_video_1",
                    userId = "usr_art",
                    mediaType = MediaType.VIDEO,
                    mediaRes = "img_urban_thumb",
                    thumbnailUrl = "",
                    videoDurationSeconds = 30,
                    title = "Procedural Neon Nebula Motion Study",
                    description = "Real-time particle simulation with audio-reactive shaders. Watching complex mathematical formulas evolve into cosmic clouds never gets old. #motionart #3d #generative #shader #particles",
                    category = "Art",
                    tags = listOf("motionart", "3d", "generative", "shader"),
                    location = "Digital Studio",
                    likeCount = 3450,
                    commentCount = 210,
                    shareCount = 560,
                    viewCount = 22100,
                    createdAt = System.currentTimeMillis() - 1000 * 60 * 1440 // 24 hours ago
                )

                val seedPosts = listOf(post1, post2, post3, post4, post5)
                postDao.insertPosts(seedPosts)

                // Initial Comments
                val comments = listOf(
                    Comment(
                        id = "c_1",
                        postId = "post_nature_video_1",
                        userId = "usr_urban",
                        text = "The dynamic range and color grading here is out of this world! Incredible work Elena! 👏",
                        likeCount = 14,
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 30
                    ),
                    Comment(
                        id = "c_2",
                        postId = "post_nature_video_1",
                        userId = "usr_tech",
                        text = "Which drone frame and ND filters were you using? The shutter angle looks silky smooth.",
                        likeCount = 6,
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 20
                    ),
                    Comment(
                        id = "c_3",
                        postId = "post_urban_photo_1",
                        userId = "usr_nature",
                        text = "Those cyan and magenta neon hues reflect so cleanly on the wet asphalt! 🌃✨",
                        likeCount = 22,
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 120
                    ),
                    Comment(
                        id = "c_4",
                        postId = "post_tech_video_1",
                        userId = "usr_current",
                        text = "What keycaps are those? The typography on them looks pristine.",
                        likeCount = 3,
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 240
                    )
                )
                socialDao.insertComments(comments)

                // Initial like by user
                socialDao.insertLike(PostLike("post_nature_video_1", "usr_current"))
                socialDao.insertBookmark(PostBookmark("post_urban_photo_1", "usr_current"))

                // Initial notifications
                val notifications = listOf(
                    AppNotification(
                        id = "n_1",
                        recipientUserId = "usr_current",
                        actorUserId = "usr_nature",
                        type = NotificationType.LIKE,
                        postId = "post_user_photo_1",
                        text = "liked your photo 'First Light in the Valley'",
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 110
                    ),
                    AppNotification(
                        id = "n_2",
                        recipientUserId = "usr_current",
                        actorUserId = "usr_urban",
                        type = NotificationType.FOLLOW,
                        text = "started following you",
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 200
                    ),
                    AppNotification(
                        id = "n_3",
                        recipientUserId = "usr_current",
                        actorUserId = "usr_tech",
                        type = NotificationType.COMMENT,
                        postId = "post_user_photo_1",
                        text = "commented: 'Great dynamic range on those pines!'",
                        createdAt = System.currentTimeMillis() - 1000 * 60 * 300
                    )
                )
                notifications.forEach { socialDao.insertNotification(it) }
            }
        }
    }
}
