package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.AppNotification
import com.example.data.model.Comment
import com.example.data.model.FollowRelation
import com.example.data.model.PostBookmark
import com.example.data.model.PostItem
import com.example.data.model.PostLike
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserAccount?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserByIdFlow(id: String): Flow<UserAccount?>

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserAccount?

    @Query("SELECT * FROM users ORDER BY followerCount DESC")
    fun getAllUsersFlow(): Flow<List<UserAccount>>

    @Query("SELECT * FROM users ORDER BY followerCount DESC")
    suspend fun getAllUsers(): List<UserAccount>

    @Query("SELECT * FROM users WHERE username LIKE '%' || :query || '%' OR displayName LIKE '%' || :query || '%'")
    fun searchUsersFlow(query: String): Flow<List<UserAccount>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserAccount>)

    @Query("UPDATE users SET followerCount = followerCount + :delta WHERE id = :userId")
    suspend fun updateFollowerCount(userId: String, delta: Int)

    @Query("UPDATE users SET followingCount = followingCount + :delta WHERE id = :userId")
    suspend fun updateFollowingCount(userId: String, delta: Int)

    @Query("UPDATE users SET postCount = postCount + :delta WHERE id = :userId")
    suspend fun updatePostCount(userId: String, delta: Int)
}

@Dao
interface PostDao {
    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun getAllPostsFlow(): Flow<List<PostItem>>

    @Query("SELECT * FROM posts WHERE userId = :userId ORDER BY createdAt DESC")
    fun getPostsByUserFlow(userId: String): Flow<List<PostItem>>

    @Query("SELECT * FROM posts WHERE id = :id LIMIT 1")
    suspend fun getPostById(id: String): PostItem?

    @Query("SELECT * FROM posts WHERE id = :id LIMIT 1")
    fun getPostByIdFlow(id: String): Flow<PostItem?>

    @Query("SELECT * FROM posts WHERE userId IN (SELECT followedId FROM follow_relations WHERE followerId = :currentUserId) ORDER BY createdAt DESC")
    fun getFollowingFeedPostsFlow(currentUserId: String): Flow<List<PostItem>>

    @Query("SELECT * FROM posts WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    fun searchPostsFlow(query: String): Flow<List<PostItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostItem>)

    @Query("UPDATE posts SET likeCount = likeCount + :delta WHERE id = :postId")
    suspend fun updateLikeCount(postId: String, delta: Int)

    @Query("UPDATE posts SET commentCount = commentCount + :delta WHERE id = :postId")
    suspend fun updateCommentCount(postId: String, delta: Int)

    @Query("UPDATE posts SET shareCount = shareCount + 1 WHERE id = :postId")
    suspend fun incrementShareCount(postId: String)

    @Query("DELETE FROM posts WHERE id = :postId")
    suspend fun deletePost(postId: String)
}

@Dao
interface SocialDao {
    // Follows
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFollow(relation: FollowRelation)

    @Query("DELETE FROM follow_relations WHERE followerId = :followerId AND followedId = :followedId")
    suspend fun deleteFollow(followerId: String, followedId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM follow_relations WHERE followerId = :followerId AND followedId = :followedId)")
    fun isFollowingFlow(followerId: String, followedId: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM follow_relations WHERE followerId = :followerId AND followedId = :followedId)")
    suspend fun isFollowing(followerId: String, followedId: String): Boolean

    @Query("SELECT followedId FROM follow_relations WHERE followerId = :followerId")
    fun getFollowingIdsFlow(followerId: String): Flow<List<String>>

    @Query("SELECT * FROM users WHERE id IN (SELECT followedId FROM follow_relations WHERE followerId = :userId)")
    fun getFollowingUsersFlow(userId: String): Flow<List<UserAccount>>

    @Query("SELECT * FROM users WHERE id IN (SELECT followerId FROM follow_relations WHERE followedId = :userId)")
    fun getFollowersUsersFlow(userId: String): Flow<List<UserAccount>>

    // Likes
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLike(like: PostLike)

    @Query("DELETE FROM post_likes WHERE postId = :postId AND userId = :userId")
    suspend fun deleteLike(postId: String, userId: String)

    @Query("SELECT postId FROM post_likes WHERE userId = :userId")
    fun getLikedPostIdsFlow(userId: String): Flow<List<String>>

    @Query("SELECT EXISTS(SELECT 1 FROM post_likes WHERE postId = :postId AND userId = :userId)")
    fun isPostLikedFlow(postId: String, userId: String): Flow<Boolean>

    // Bookmarks
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: PostBookmark)

    @Query("DELETE FROM post_bookmarks WHERE postId = :postId AND userId = :userId")
    suspend fun deleteBookmark(postId: String, userId: String)

    @Query("SELECT postId FROM post_bookmarks WHERE userId = :userId")
    fun getBookmarkedPostIdsFlow(userId: String): Flow<List<String>>

    @Query("SELECT * FROM posts WHERE id IN (SELECT postId FROM post_bookmarks WHERE userId = :userId) ORDER BY createdAt DESC")
    fun getBookmarkedPostsFlow(userId: String): Flow<List<PostItem>>

    // Comments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: Comment)

    @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY createdAt ASC")
    fun getCommentsForPostFlow(postId: String): Flow<List<Comment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComments(comments: List<Comment>)

    // Notifications
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("SELECT * FROM notifications WHERE recipientUserId = :userId ORDER BY createdAt DESC")
    fun getNotificationsForUserFlow(userId: String): Flow<List<AppNotification>>

    @Query("UPDATE notifications SET isRead = 1 WHERE recipientUserId = :userId")
    suspend fun markAllNotificationsAsRead(userId: String)
}
