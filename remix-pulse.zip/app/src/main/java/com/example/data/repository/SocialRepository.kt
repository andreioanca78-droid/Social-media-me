package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.Comment
import com.example.data.model.FeedPostUiModel
import com.example.data.model.FollowRelation
import com.example.data.model.MediaType
import com.example.data.model.NotificationType
import com.example.data.model.PostBookmark
import com.example.data.model.PostItem
import com.example.data.model.PostLike
import com.example.data.model.UserAccount
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

class SocialRepository(
    private val db: AppDatabase,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val userDao = db.userDao()
    private val postDao = db.postDao()
    private val socialDao = db.socialDao()

    private val _currentUserId = MutableStateFlow("usr_current")
    val currentUserId = _currentUserId.asStateFlow()

    val currentUserFlow: Flow<UserAccount?> = _currentUserId.flatMapLatest { id ->
        userDao.getUserByIdFlow(id)
    }.flowOn(ioDispatcher)

    val allUsersFlow: Flow<List<UserAccount>> = userDao.getAllUsersFlow().flowOn(ioDispatcher)

    fun getUserByIdFlow(userId: String): Flow<UserAccount?> =
        userDao.getUserByIdFlow(userId).flowOn(ioDispatcher)

    suspend fun getUserById(userId: String): UserAccount? = withContext(ioDispatcher) {
        userDao.getUserById(userId)
    }

    fun isFollowingFlow(targetUserId: String): Flow<Boolean> = _currentUserId.flatMapLatest { currentId ->
        socialDao.isFollowingFlow(currentId, targetUserId)
    }.flowOn(ioDispatcher)

    fun getPersonalizedFeed(
        categoryFilter: String? = null
    ): Flow<List<FeedPostUiModel>> {
        val baseFlow = combine(
            postDao.getAllPostsFlow(),
            userDao.getAllUsersFlow(),
            currentUserFlow
        ) { posts: List<PostItem>, users: List<UserAccount>, currentUser: UserAccount? ->
            Triple(posts, users, currentUser)
        }

        val userInteractionsFlow = combine(
            _currentUserId.flatMapLatest { socialDao.getLikedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getBookmarkedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getFollowingIdsFlow(it) }
        ) { likedIds: List<String>, bookmarkedIds: List<String>, followingIds: List<String> ->
            Triple(likedIds, bookmarkedIds, followingIds)
        }

        return combine(baseFlow, userInteractionsFlow) { (posts, users, currentUser), (likedIds, bookmarkedIds, followingIds) ->
            val userMap = users.associateBy { it.id }
            val likedSet = likedIds.toSet()
            val bookmarkedSet = bookmarkedIds.toSet()
            val followingSet = followingIds.toSet()
            val userInterests = currentUser?.interests?.map { it.lowercase() }?.toSet() ?: emptySet()

            var filteredPosts = posts
            if (!categoryFilter.isNullOrBlank() && categoryFilter != "All") {
                filteredPosts = posts.filter { it.category.equals(categoryFilter, ignoreCase = true) }
            }

            // Personalized algorithm scoring
            val scoredPosts = filteredPosts.map { post ->
                val author = userMap[post.userId] ?: UserAccount(
                    id = post.userId,
                    username = "creator",
                    displayName = "Creator",
                    bio = "",
                    avatarRes = "avatar_user",
                    coverRes = "cover_user",
                    interests = emptyList()
                )

                var score = 0.0

                // 1. Followed creators get a priority boost
                if (followingSet.contains(post.userId)) {
                    score += 60.0
                }

                // 2. Interest / Category matching
                if (userInterests.contains(post.category.lowercase())) {
                    score += 40.0
                }
                val matchingTagsCount = post.tags.count { tag -> userInterests.contains(tag.lowercase()) }
                score += matchingTagsCount * 15.0

                // 3. Engagement weight
                score += (post.likeCount * 0.05).coerceAtMost(25.0)
                score += (post.commentCount * 0.1).coerceAtMost(20.0)

                // 4. Recency factor (posts from last 24h get higher weight)
                val hoursAgo = ((System.currentTimeMillis() - post.createdAt) / (1000.0 * 60 * 60)).coerceAtLeast(0.1)
                val recencyScore = 100.0 / (1.0 + (hoursAgo * 0.15))
                score += recencyScore

                val uiModel = FeedPostUiModel(
                    post = post,
                    author = author,
                    isLiked = likedSet.contains(post.id),
                    isBookmarked = bookmarkedSet.contains(post.id),
                    isFollowingAuthor = followingSet.contains(post.userId)
                )
                Pair(uiModel, score)
            }

            // Sort by personalized score descending
            scoredPosts.sortedByDescending { it.second }.map { it.first }
        }.flowOn(ioDispatcher)
    }

    fun getFollowingFeed(): Flow<List<FeedPostUiModel>> {
        return combine(
            _currentUserId.flatMapLatest { postDao.getFollowingFeedPostsFlow(it) },
            userDao.getAllUsersFlow(),
            _currentUserId.flatMapLatest { socialDao.getLikedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getBookmarkedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getFollowingIdsFlow(it) }
        ) { posts, users, likedIds, bookmarkedIds, followingIds ->
            val userMap = users.associateBy { it.id }
            val likedSet = likedIds.toSet()
            val bookmarkedSet = bookmarkedIds.toSet()
            val followingSet = followingIds.toSet()

            posts.map { post ->
                val author = userMap[post.userId] ?: UserAccount(
                    id = post.userId,
                    username = "creator",
                    displayName = "Creator",
                    bio = "",
                    avatarRes = "avatar_user",
                    coverRes = "cover_user",
                    interests = emptyList()
                )
                FeedPostUiModel(
                    post = post,
                    author = author,
                    isLiked = likedSet.contains(post.id),
                    isBookmarked = bookmarkedSet.contains(post.id),
                    isFollowingAuthor = followingSet.contains(post.userId)
                )
            }
        }.flowOn(ioDispatcher)
    }

    fun getExploreFeed(query: String = "", category: String? = null): Flow<List<FeedPostUiModel>> {
        val basePostsFlow = if (query.isBlank()) {
            postDao.getAllPostsFlow()
        } else {
            postDao.searchPostsFlow(query)
        }

        return combine(
            basePostsFlow,
            userDao.getAllUsersFlow(),
            _currentUserId.flatMapLatest { socialDao.getLikedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getBookmarkedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getFollowingIdsFlow(it) }
        ) { posts, users, likedIds, bookmarkedIds, followingIds ->
            val userMap = users.associateBy { it.id }
            val likedSet = likedIds.toSet()
            val bookmarkedSet = bookmarkedIds.toSet()
            val followingSet = followingIds.toSet()

            var result = posts
            if (!category.isNullOrBlank() && category != "All") {
                result = result.filter { it.category.equals(category, ignoreCase = true) }
            }

            result.map { post ->
                val author = userMap[post.userId] ?: UserAccount(
                    id = post.userId,
                    username = "creator",
                    displayName = "Creator",
                    bio = "",
                    avatarRes = "avatar_user",
                    coverRes = "cover_user",
                    interests = emptyList()
                )
                FeedPostUiModel(
                    post = post,
                    author = author,
                    isLiked = likedSet.contains(post.id),
                    isBookmarked = bookmarkedSet.contains(post.id),
                    isFollowingAuthor = followingSet.contains(post.userId)
                )
            }
        }.flowOn(ioDispatcher)
    }

    fun getUserPosts(userId: String): Flow<List<FeedPostUiModel>> {
        return combine(
            postDao.getPostsByUserFlow(userId),
            userDao.getUserByIdFlow(userId),
            _currentUserId.flatMapLatest { socialDao.getLikedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getBookmarkedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getFollowingIdsFlow(it) }
        ) { posts, user, likedIds, bookmarkedIds, followingIds ->
            val author = user ?: UserAccount(
                id = userId,
                username = "creator",
                displayName = "Creator",
                bio = "",
                avatarRes = "avatar_user",
                coverRes = "cover_user",
                interests = emptyList()
            )
            val likedSet = likedIds.toSet()
            val bookmarkedSet = bookmarkedIds.toSet()
            val followingSet = followingIds.toSet()

            posts.map { post ->
                FeedPostUiModel(
                    post = post,
                    author = author,
                    isLiked = likedSet.contains(post.id),
                    isBookmarked = bookmarkedSet.contains(post.id),
                    isFollowingAuthor = followingSet.contains(post.userId)
                )
            }
        }.flowOn(ioDispatcher)
    }

    fun getBookmarkedPosts(): Flow<List<FeedPostUiModel>> {
        return combine(
            _currentUserId.flatMapLatest { socialDao.getBookmarkedPostsFlow(it) },
            userDao.getAllUsersFlow(),
            _currentUserId.flatMapLatest { socialDao.getLikedPostIdsFlow(it) },
            _currentUserId.flatMapLatest { socialDao.getFollowingIdsFlow(it) }
        ) { posts, users, likedIds, followingIds ->
            val userMap = users.associateBy { it.id }
            val likedSet = likedIds.toSet()
            val followingSet = followingIds.toSet()

            posts.map { post ->
                val author = userMap[post.userId] ?: UserAccount(
                    id = post.userId,
                    username = "creator",
                    displayName = "Creator",
                    bio = "",
                    avatarRes = "avatar_user",
                    coverRes = "cover_user",
                    interests = emptyList()
                )
                FeedPostUiModel(
                    post = post,
                    author = author,
                    isLiked = likedSet.contains(post.id),
                    isBookmarked = true,
                    isFollowingAuthor = followingSet.contains(post.userId)
                )
            }
        }.flowOn(ioDispatcher)
    }

    suspend fun switchAccount(userId: String) = withContext(ioDispatcher) {
        _currentUserId.value = userId
    }

    suspend fun createAccount(
        username: String,
        displayName: String,
        bio: String,
        avatarRes: String,
        interests: List<String>
    ): UserAccount = withContext(ioDispatcher) {
        val cleanUsername = username.trim().removePrefix("@").lowercase().replace(" ", "_")
        val newUser = UserAccount(
            id = "usr_" + UUID.randomUUID().toString().take(8),
            username = cleanUsername,
            displayName = displayName.trim(),
            bio = bio.trim(),
            avatarRes = avatarRes,
            coverRes = "cover_user",
            interests = interests,
            followerCount = 0,
            followingCount = 0,
            postCount = 0,
            isVerified = false,
            createdAt = System.currentTimeMillis()
        )
        userDao.insertUser(newUser)
        _currentUserId.value = newUser.id
        newUser
    }

    suspend fun createPost(
        mediaType: MediaType,
        mediaRes: String,
        title: String,
        description: String,
        category: String,
        tags: List<String>,
        location: String,
        videoDuration: Int = 15
    ): PostItem = withContext(ioDispatcher) {
        val currentUserId = _currentUserId.value
        val postId = "post_" + UUID.randomUUID().toString().take(8)

        // Parse extra hashtags from description
        val regex = Regex("#(\\w+)")
        val foundTags = regex.findAll(description).map { it.groupValues[1] }.toList()
        val allTags = (tags + foundTags).distinct()

        val post = PostItem(
            id = postId,
            userId = currentUserId,
            mediaType = mediaType,
            mediaRes = mediaRes,
            videoDurationSeconds = if (mediaType == MediaType.VIDEO) videoDuration else 0,
            title = title.trim(),
            description = description.trim(),
            category = category,
            tags = allTags,
            location = location.trim(),
            likeCount = 0,
            commentCount = 0,
            shareCount = 0,
            viewCount = 1,
            createdAt = System.currentTimeMillis()
        )
        postDao.insertPost(post)
        userDao.updatePostCount(currentUserId, 1)

        // Generate notifications for followers
        val author = userDao.getUserById(currentUserId)
        val followers = socialDao.getFollowersUsersFlow(currentUserId)
        // Insert a self activity notification
        socialDao.insertNotification(
            AppNotification(
                id = "n_" + UUID.randomUUID().toString().take(8),
                recipientUserId = currentUserId,
                actorUserId = currentUserId,
                type = NotificationType.NEW_POST,
                postId = postId,
                text = "Your post '${title.take(30)}' was published successfully! 🎉"
            )
        )
        post
    }

    suspend fun toggleLike(postId: String) = withContext(ioDispatcher) {
        val currentUserId = _currentUserId.value
        val post = postDao.getPostById(postId) ?: return@withContext

        val isLiked = socialDao.isPostLikedFlow(postId, currentUserId)
        // Check current like state synchronously
        val alreadyLiked = db.openHelper.readableDatabase.query(
            "SELECT 1 FROM post_likes WHERE postId = ? AND userId = ?",
            arrayOf(postId, currentUserId)
        ).use { it.moveToFirst() }

        if (alreadyLiked) {
            socialDao.deleteLike(postId, currentUserId)
            postDao.updateLikeCount(postId, -1)
        } else {
            socialDao.insertLike(PostLike(postId, currentUserId))
            postDao.updateLikeCount(postId, 1)

            // Send notification to author if not self
            if (post.userId != currentUserId) {
                val author = userDao.getUserById(currentUserId)
                socialDao.insertNotification(
                    AppNotification(
                        id = "n_" + UUID.randomUUID().toString().take(8),
                        recipientUserId = post.userId,
                        actorUserId = currentUserId,
                        type = NotificationType.LIKE,
                        postId = postId,
                        text = "liked your ${if (post.mediaType == MediaType.VIDEO) "video" else "photo"} '${post.title.take(25)}'"
                    )
                )
            }
        }
    }

    suspend fun toggleBookmark(postId: String) = withContext(ioDispatcher) {
        val currentUserId = _currentUserId.value
        val alreadyBookmarked = db.openHelper.readableDatabase.query(
            "SELECT 1 FROM post_bookmarks WHERE postId = ? AND userId = ?",
            arrayOf(postId, currentUserId)
        ).use { it.moveToFirst() }

        if (alreadyBookmarked) {
            socialDao.deleteBookmark(postId, currentUserId)
        } else {
            socialDao.insertBookmark(PostBookmark(postId, currentUserId))
        }
    }

    suspend fun toggleFollow(targetUserId: String) = withContext(ioDispatcher) {
        val currentUserId = _currentUserId.value
        if (currentUserId == targetUserId) return@withContext

        val isFollowing = socialDao.isFollowing(currentUserId, targetUserId)
        if (isFollowing) {
            socialDao.deleteFollow(currentUserId, targetUserId)
            userDao.updateFollowerCount(targetUserId, -1)
            userDao.updateFollowingCount(currentUserId, -1)
        } else {
            socialDao.insertFollow(FollowRelation(currentUserId, targetUserId))
            userDao.updateFollowerCount(targetUserId, 1)
            userDao.updateFollowingCount(currentUserId, 1)

            // Notify target user
            socialDao.insertNotification(
                AppNotification(
                    id = "n_" + UUID.randomUUID().toString().take(8),
                    recipientUserId = targetUserId,
                    actorUserId = currentUserId,
                    type = NotificationType.FOLLOW,
                    text = "started following you"
                )
            )
        }
    }

    suspend fun addComment(postId: String, text: String): Comment = withContext(ioDispatcher) {
        val currentUserId = _currentUserId.value
        val commentId = "c_" + UUID.randomUUID().toString().take(8)
        val comment = Comment(
            id = commentId,
            postId = postId,
            userId = currentUserId,
            text = text.trim(),
            likeCount = 0,
            createdAt = System.currentTimeMillis()
        )
        socialDao.insertComment(comment)
        postDao.updateCommentCount(postId, 1)

        val post = postDao.getPostById(postId)
        if (post != null && post.userId != currentUserId) {
            socialDao.insertNotification(
                AppNotification(
                    id = "n_" + UUID.randomUUID().toString().take(8),
                    recipientUserId = post.userId,
                    actorUserId = currentUserId,
                    type = NotificationType.COMMENT,
                    postId = postId,
                    text = "commented: '${text.take(30)}'"
                )
            )
        }
        comment
    }

    fun getCommentsForPost(postId: String): Flow<List<Pair<Comment, UserAccount?>>> {
        return combine(
            socialDao.getCommentsForPostFlow(postId),
            userDao.getAllUsersFlow()
        ) { comments, users ->
            val userMap = users.associateBy { it.id }
            comments.map { comment ->
                Pair(comment, userMap[comment.userId])
            }
        }.flowOn(ioDispatcher)
    }

    fun getNotifications(): Flow<List<Pair<AppNotification, UserAccount?>>> {
        return _currentUserId.flatMapLatest { currentId ->
            combine(
                socialDao.getNotificationsForUserFlow(currentId),
                userDao.getAllUsersFlow()
            ) { notifications, users ->
                val userMap = users.associateBy { it.id }
                notifications.map { notif ->
                    Pair(notif, userMap[notif.actorUserId])
                }
            }
        }.flowOn(ioDispatcher)
    }

    suspend fun markNotificationsAsRead() = withContext(ioDispatcher) {
        socialDao.markAllNotificationsAsRead(_currentUserId.value)
    }
}
