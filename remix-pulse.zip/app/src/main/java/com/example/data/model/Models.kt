package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MediaType {
    PHOTO,
    VIDEO
}

enum class NotificationType {
    LIKE,
    COMMENT,
    FOLLOW,
    NEW_POST
}

@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey val id: String,
    val username: String,
    val displayName: String,
    val bio: String,
    val avatarRes: String, // Resource name or URI or seed
    val coverRes: String,
    val interests: List<String>,
    val followerCount: Int = 0,
    val followingCount: Int = 0,
    val postCount: Int = 0,
    val isVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "posts")
data class PostItem(
    @PrimaryKey val id: String,
    val userId: String,
    val mediaType: MediaType,
    val mediaRes: String, // Resource drawable name, local URI, or media identifier
    val thumbnailUrl: String = "",
    val videoDurationSeconds: Int = 0,
    val title: String,
    val description: String,
    val category: String,
    val tags: List<String>,
    val location: String = "",
    val likeCount: Int = 0,
    val commentCount: Int = 0,
    val shareCount: Int = 0,
    val viewCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "follow_relations", primaryKeys = ["followerId", "followedId"])
data class FollowRelation(
    val followerId: String,
    val followedId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "post_likes", primaryKeys = ["postId", "userId"])
data class PostLike(
    val postId: String,
    val userId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "post_bookmarks", primaryKeys = ["postId", "userId"])
data class PostBookmark(
    val postId: String,
    val userId: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class Comment(
    @PrimaryKey val id: String,
    val postId: String,
    val userId: String,
    val text: String,
    val likeCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey val id: String,
    val recipientUserId: String,
    val actorUserId: String,
    val type: NotificationType,
    val postId: String? = null,
    val text: String,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// Combined UI Post item with populated author and interaction status
data class FeedPostUiModel(
    val post: PostItem,
    val author: UserAccount,
    val isLiked: Boolean,
    val isBookmarked: Boolean,
    val isFollowingAuthor: Boolean
)
