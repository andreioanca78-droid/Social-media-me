package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Palette - Primary & Secondary Accent Tokens
val VibrantPrimary = Color(0xFF6750A4)
val VibrantPrimaryDark = Color(0xFF381E72)
val VibrantPrimaryLight = Color(0xFFD0BCFF)
val VibrantPrimaryContainer = Color(0xFFEADDFF)
val VibrantOnPrimaryContainer = Color(0xFF21005D)

val VibrantSecondary = Color(0xFF625B71)
val VibrantSecondaryContainer = Color(0xFFE8DEF8)
val VibrantOnSecondaryContainer = Color(0xFF1D192B)

val VibrantTertiary = Color(0xFF7D5260)
val VibrantTertiaryContainer = Color(0xFFFFD8E4)
val VibrantOnTertiaryContainer = Color(0xFF31111D)

val VibrantHeartRed = Color(0xFFB3261E)
val VibrantSuccessGreen = Color(0xFF2E7D32)
val VibrantWarningAmber = Color(0xFFF57C00)

// Backward compatible aliases
val PulseViolet = VibrantPrimary
val PulseVioletDark = VibrantPrimaryDark
val PulseCyan = Color(0xFF006874)
val PulseCyanLight = Color(0xFF97F0FF)
val PulsePink = Color(0xFF9C4146)
val PulseAmber = VibrantWarningAmber
val PulseEmerald = VibrantSuccessGreen

// Light Theme Surface & Text Tokens
val VibrantLightBackground = Color(0xFFFEF7FF)
val VibrantLightSurface = Color(0xFFFFFFFF)
val VibrantLightSurfaceContainer = Color(0xFFF3EDF7)
val VibrantLightSurfaceVariant = Color(0xFFE7E0EC)
val VibrantLightOutline = Color(0xFFEADDFF)
val VibrantLightOutlineVariant = Color(0xFFCAC4D0)

val VibrantTextPrimaryLight = Color(0xFF1D1B20)
val VibrantTextHeadingLight = Color(0xFF21005D)
val VibrantTextSecondaryLight = Color(0xFF49454F)
val VibrantTextMutedLight = Color(0xFF79747E)

// Dark Theme Surface & Text Tokens
val VibrantDarkBackground = Color(0xFF141218)
val VibrantDarkSurface = Color(0xFF1D1B20)
val VibrantDarkSurfaceContainer = Color(0xFF211F26)
val VibrantDarkSurfaceVariant = Color(0xFF49454F)
val VibrantDarkOutline = Color(0xFF49454F)
val VibrantDarkOutlineVariant = Color(0xFF938F99)

val VibrantTextPrimaryDark = Color(0xFFE6E1E5)
val VibrantTextSecondaryDark = Color(0xFFCAC4D0)
val VibrantTextMutedDark = Color(0xFF938F99)

// Standard Color Aliases
val DarkBackground = VibrantDarkBackground
val DarkSurface = VibrantDarkSurface
val DarkSurfaceVariant = VibrantDarkSurfaceVariant
val DarkSurfaceHighlight = Color(0xFF2B2930)

val TextPrimaryDark = VibrantTextPrimaryDark
val TextSecondaryDark = VibrantTextSecondaryDark
val TextMutedDark = VibrantTextMutedDark

val LightBackground = VibrantLightBackground
val LightSurface = VibrantLightSurface
val LightSurfaceVariant = VibrantLightSurfaceVariant
val LightSurfaceHighlight = VibrantLightOutline

val TextPrimaryLight = VibrantTextPrimaryLight
val TextSecondaryLight = VibrantTextSecondaryLight
val TextMutedLight = VibrantTextMutedLight

