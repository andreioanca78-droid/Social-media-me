package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = VibrantPrimaryLight,
    onPrimary = VibrantPrimaryDark,
    primaryContainer = VibrantPrimaryDark,
    onPrimaryContainer = VibrantPrimaryContainer,
    secondary = VibrantSecondaryContainer,
    onSecondary = VibrantOnSecondaryContainer,
    secondaryContainer = Color(0xFF4A4458),
    onSecondaryContainer = VibrantSecondaryContainer,
    tertiary = VibrantTertiaryContainer,
    onTertiary = VibrantOnTertiaryContainer,
    background = VibrantDarkBackground,
    onBackground = VibrantTextPrimaryDark,
    surface = VibrantDarkSurface,
    onSurface = VibrantTextPrimaryDark,
    surfaceVariant = VibrantDarkSurfaceVariant,
    onSurfaceVariant = VibrantTextSecondaryDark,
    outline = VibrantDarkOutline,
    outlineVariant = VibrantDarkOutlineVariant
)

private val LightColorScheme = lightColorScheme(
    primary = VibrantPrimary,
    onPrimary = Color.White,
    primaryContainer = VibrantPrimaryContainer,
    onPrimaryContainer = VibrantOnPrimaryContainer,
    secondary = VibrantSecondary,
    onSecondary = Color.White,
    secondaryContainer = VibrantSecondaryContainer,
    onSecondaryContainer = VibrantOnSecondaryContainer,
    tertiary = VibrantTertiary,
    onTertiary = Color.White,
    tertiaryContainer = VibrantTertiaryContainer,
    onTertiaryContainer = VibrantOnTertiaryContainer,
    background = VibrantLightBackground,
    onBackground = VibrantTextPrimaryLight,
    surface = VibrantLightSurface,
    onSurface = VibrantTextPrimaryLight,
    surfaceVariant = VibrantLightSurfaceVariant,
    onSurfaceVariant = VibrantTextSecondaryLight,
    outline = VibrantLightOutline,
    outlineVariant = VibrantLightOutlineVariant
)

@Composable
fun PulseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded vibrant palette by default
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    PulseTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

