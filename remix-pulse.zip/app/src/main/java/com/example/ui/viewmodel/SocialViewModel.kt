package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.Comment
import com.example.data.model.FeedPostUiModel
import com.example.data.model.MediaType
import com.example.data.model.PostItem
import com.example.data.model.UserAccount
import com.example.data.repository.SocialRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class FeedTab {
    FOR_YOU,
    FOLLOWING
}

enum class NavigationScreen {
    FEED,
    EXPLORE,
    CREATE_POST,
    NOTIFICATIONS,
    PROFILE,
    CREATOR_PROFILE
}

class SocialViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = SocialRepository(database)

    // Current navigation state
    private val _currentScreen = MutableStateFlow(NavigationScreen.FEED)
    val currentScreen = _currentScreen.asStateFlow()

    // Feed tabs & category filters
    private val _activeFeedTab = MutableStateFlow(FeedTab.FOR_YOU)
    val activeFeedTab = _activeFeedTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    // Active User
    val currentUser: StateFlow<UserAccount?> = repository.currentUserFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val allUsers: StateFlow<List<UserAccount>> = repository.allUsersFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Personalized Feed (For You)
    val personalizedFeed: StateFlow<List<FeedPostUiModel>> = _selectedCategory.flatMapLatest { cat ->
        repository.getPersonalizedFeed(cat)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Following Feed
    val followingFeed: StateFlow<List<FeedPostUiModel>> = repository.getFollowingFeed().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Explore / Search
    private val _exploreQuery = MutableStateFlow("")
    val exploreQuery = _exploreQuery.asStateFlow()

    private val _exploreCategory = MutableStateFlow<String?>("All")
    val exploreCategory = _exploreCategory.asStateFlow()

    val exploreFeed: StateFlow<List<FeedPostUiModel>> = combine(
        _exploreQuery,
        _exploreCategory
    ) { query, cat ->
        Pair(query, cat)
    }.flatMapLatest { (query, cat) ->
        repository.getExploreFeed(query, cat)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selected Creator Profile state
    private val _selectedProfileUser = MutableStateFlow<UserAccount?>(null)
    val selectedProfileUser = _selectedProfileUser.asStateFlow()

    val selectedUserPosts: StateFlow<List<FeedPostUiModel>> = _selectedProfileUser.flatMapLatest { user ->
        if (user != null) {
            repository.getUserPosts(user.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val currentUserPosts: StateFlow<List<FeedPostUiModel>> = currentUser.flatMapLatest { user ->
        if (user != null) {
            repository.getUserPosts(user.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val bookmarkedPosts: StateFlow<List<FeedPostUiModel>> = repository.getBookmarkedPosts().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active Comments Sheet state
    private val _activeCommentsPost = MutableStateFlow<FeedPostUiModel?>(null)
    val activeCommentsPost = _activeCommentsPost.asStateFlow()

    val activePostComments: StateFlow<List<Pair<Comment, UserAccount?>>> = _activeCommentsPost.flatMapLatest { postUi ->
        if (postUi != null) {
            repository.getCommentsForPost(postUi.post.id)
        } else {
            flowOf(emptyList())
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Notifications
    val notifications: StateFlow<List<Pair<AppNotification, UserAccount?>>> = repository.getNotifications().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selected Post Detail Modal / Viewer
    private val _selectedPostDetail = MutableStateFlow<FeedPostUiModel?>(null)
    val selectedPostDetail = _selectedPostDetail.asStateFlow()

    // Dialog flags
    private val _showAccountSwitcher = MutableStateFlow(false)
    val showAccountSwitcher = _showAccountSwitcher.asStateFlow()

    private val _showCreateAccountDialog = MutableStateFlow(false)
    val showCreateAccountDialog = _showCreateAccountDialog.asStateFlow()

    // --- Actions ---

    fun navigateTo(screen: NavigationScreen) {
        _currentScreen.value = screen
    }

    fun setFeedTab(tab: FeedTab) {
        _activeFeedTab.value = tab
    }

    fun setSelectedCategory(category: String?) {
        _selectedCategory.value = category
    }

    fun setExploreQuery(query: String) {
        _exploreQuery.value = query
    }

    fun setExploreCategory(category: String?) {
        _exploreCategory.value = category
    }

    fun viewUserProfile(user: UserAccount) {
        _selectedProfileUser.value = user
        _currentScreen.value = NavigationScreen.CREATOR_PROFILE
    }

    fun openPostDetail(post: FeedPostUiModel) {
        _selectedPostDetail.value = post
    }

    fun closePostDetail() {
        _selectedPostDetail.value = null
    }

    fun openComments(postUi: FeedPostUiModel) {
        _activeCommentsPost.value = postUi
    }

    fun closeComments() {
        _activeCommentsPost.value = null
    }

    fun setShowAccountSwitcher(show: Boolean) {
        _showAccountSwitcher.value = show
    }

    fun setShowCreateAccountDialog(show: Boolean) {
        _showCreateAccountDialog.value = show
    }

    fun toggleLike(postId: String) {
        viewModelScope.launch {
            repository.toggleLike(postId)
        }
    }

    fun toggleBookmark(postId: String) {
        viewModelScope.launch {
            repository.toggleBookmark(postId)
        }
    }

    fun toggleFollow(targetUserId: String) {
        viewModelScope.launch {
            repository.toggleFollow(targetUserId)
        }
    }

    fun addComment(postId: String, text: String) {
        viewModelScope.launch {
            repository.addComment(postId, text)
        }
    }

    fun switchAccount(userId: String) {
        viewModelScope.launch {
            repository.switchAccount(userId)
            _showAccountSwitcher.value = false
        }
    }

    fun createAccount(
        username: String,
        displayName: String,
        bio: String,
        avatarRes: String,
        interests: List<String>
    ) {
        viewModelScope.launch {
            repository.createAccount(username, displayName, bio, avatarRes, interests)
            _showCreateAccountDialog.value = false
            _showAccountSwitcher.value = false
        }
    }

    fun uploadPost(
        mediaType: MediaType,
        mediaRes: String,
        title: String,
        description: String,
        category: String,
        tags: List<String>,
        location: String,
        videoDuration: Int = 15,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.createPost(
                mediaType = mediaType,
                mediaRes = mediaRes,
                title = title,
                description = description,
                category = category,
                tags = tags,
                location = location,
                videoDuration = videoDuration
            )
            _currentScreen.value = NavigationScreen.FEED
            onSuccess()
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            repository.markNotificationsAsRead()
        }
    }
}
