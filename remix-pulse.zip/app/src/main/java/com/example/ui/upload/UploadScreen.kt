package com.example.ui.upload

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaType
import com.example.data.model.UserAccount
import com.example.ui.components.AvatarImage
import com.example.ui.components.MediaImage
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.PulseCyan
import com.example.ui.theme.PulsePink
import com.example.ui.theme.PulseViolet
import com.example.ui.theme.PulseVioletDark

data class PresetMedia(
    val id: String,
    val title: String,
    val resName: String,
    val type: MediaType,
    val category: String,
    val defaultTitle: String,
    val defaultDesc: String,
    val defaultTags: List<String>,
    val defaultLocation: String
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(
    currentUser: UserAccount?,
    onPublish: (
        mediaType: MediaType,
        mediaRes: String,
        title: String,
        description: String,
        category: String,
        tags: List<String>,
        location: String,
        videoDuration: Int
    ) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedMediaType by remember { mutableStateOf(MediaType.PHOTO) }
    var selectedMediaRes by remember { mutableStateOf("img_nature_thumb") }
    var customMediaUri by remember { mutableStateOf<Uri?>(null) }
    var postTitle by remember { mutableStateOf("") }
    var postDescription by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Photography") }
    var locationText by remember { mutableStateOf("") }
    var videoDurationSeconds by remember { mutableIntStateOf(15) }
    var isPublishing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val presetClips = listOf(
        PresetMedia(
            id = "preset_nature",
            title = "Alpine Sunrise Flight",
            resName = "img_nature_thumb",
            type = MediaType.VIDEO,
            category = "Nature",
            defaultTitle = "Misty Mountain Sunrise 4K",
            defaultDesc = "Golden light sweeping across the pine ridges. Nature at its finest. #nature #cinematic #sunrise #drone",
            defaultTags = listOf("nature", "cinematic", "sunrise", "drone"),
            defaultLocation = "Banff, Canada"
        ),
        PresetMedia(
            id = "preset_urban",
            title = "Cyberpunk Tokyo Rain",
            resName = "img_urban_thumb",
            type = MediaType.PHOTO,
            category = "Photography",
            defaultTitle = "Tokyo After Dark: Neon Reflections",
            defaultDesc = "Reflections in rainy Shinjuku alleyways. #tokyo #street #neon #night #vibes",
            defaultTags = listOf("tokyo", "street", "neon", "night"),
            defaultLocation = "Tokyo, Japan"
        ),
        PresetMedia(
            id = "preset_tech",
            title = "Minimal Studio Setup",
            resName = "img_tech_thumb",
            type = MediaType.VIDEO,
            category = "Tech",
            defaultTitle = "Modern Aesthetic Coding Station",
            defaultDesc = "Warm ambient glow, mechanical keystrokes & clean cables. #desksetup #workspace #tech #minimal",
            defaultTags = listOf("desksetup", "workspace", "tech", "minimal"),
            defaultLocation = "San Francisco, CA"
        ),
        PresetMedia(
            id = "preset_art",
            title = "Generative Motion Study",
            resName = "img_urban_thumb",
            type = MediaType.VIDEO,
            category = "Art",
            defaultTitle = "Cosmic Particle Simulation",
            defaultDesc = "Realtime audio-reactive 3D animation. #motion #3d #generative #shader",
            defaultTags = listOf("motion", "3d", "generative", "shader"),
            defaultLocation = "Digital Studio"
        )
    )

    val categories = listOf("Photography", "Cinematic", "Tech", "Nature", "Art", "Travel", "Lifestyle")
    val quickHashtags = listOf("#cinematic", "#aesthetic", "#drone", "#photography", "#tech", "#travel", "#explore", "#art", "#vibes")
    val quickLocations = listOf("Banff, Canada", "Tokyo, Japan", "San Francisco, CA", "London, UK", "New York, NY", "Digital Studio")

    // Image/Video gallery launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            customMediaUri = uri
            selectedMediaRes = uri.toString()
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .imePadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCancel) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            Text(
                text = "New Post",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            // Top Publish Button
            Button(
                onClick = {
                    if (postTitle.isBlank()) {
                        errorMessage = "Please enter a title for your post"
                        return@Button
                    }
                    isPublishing = true
                    errorMessage = null
                    val regex = Regex("#(\\w+)")
                    val foundTags = regex.findAll(postDescription).map { it.groupValues[1] }.toList()

                    onPublish(
                        selectedMediaType,
                        selectedMediaRes,
                        postTitle,
                        postDescription,
                        selectedCategory,
                        foundTags,
                        locationText,
                        if (selectedMediaType == MediaType.VIDEO) videoDurationSeconds else 0
                    )
                },
                enabled = !isPublishing && postTitle.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(50),
                modifier = Modifier.testTag("publish_post_button")
            ) {
                if (isPublishing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("Share", fontWeight = FontWeight.Bold)
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Media Type Selector (Photo vs Video)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.padding(2.dp)
                ) {
                    Row(modifier = Modifier.padding(4.dp)) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (selectedMediaType == MediaType.PHOTO) MaterialTheme.colorScheme.primary else Color.Transparent,
                            modifier = Modifier
                                .clickable { selectedMediaType = MediaType.PHOTO }
                                .testTag("select_photo_type")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PhotoCamera,
                                    contentDescription = null,
                                    tint = if (selectedMediaType == MediaType.PHOTO) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Photo",
                                    color = if (selectedMediaType == MediaType.PHOTO) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (selectedMediaType == MediaType.VIDEO) MaterialTheme.colorScheme.primary else Color.Transparent,
                            modifier = Modifier
                                .clickable { selectedMediaType = MediaType.VIDEO }
                                .testTag("select_video_type")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Videocam,
                                    contentDescription = null,
                                    tint = if (selectedMediaType == MediaType.VIDEO) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Video Clip",
                                    color = if (selectedMediaType == MediaType.VIDEO) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live Media Preview Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(if (selectedMediaType == MediaType.VIDEO) 1.35f else 1.25f),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (selectedMediaType == MediaType.VIDEO) {
                        VideoPlayerView(
                            mediaRes = selectedMediaRes,
                            durationSeconds = videoDurationSeconds,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        MediaImage(
                            mediaRes = selectedMediaRes,
                            contentDescription = "Selected media preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    // Choose Media Overlay Actions
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = 0.75f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                            modifier = Modifier.clickable {
                                galleryLauncher.launch(if (selectedMediaType == MediaType.VIDEO) "video/*" else "image/*")
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = PulseCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Pick File",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Preset Media Clips / Photos library
            Text(
                text = "Preset Library (4K High Quality)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(presetClips) { preset ->
                    val isSelected = selectedMediaRes == preset.resName && selectedMediaType == preset.type
                    Card(
                        modifier = Modifier
                            .width(130.dp)
                            .clickable {
                                selectedMediaRes = preset.resName
                                selectedMediaType = preset.type
                                if (postTitle.isBlank()) postTitle = preset.defaultTitle
                                if (postDescription.isBlank()) postDescription = preset.defaultDesc
                                selectedCategory = preset.category
                                if (locationText.isBlank()) locationText = preset.defaultLocation
                            },
                        shape = RoundedCornerShape(12.dp),
                        border = if (isSelected) BorderStroke(2.dp, PulseCyan) else BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(68.dp)
                            ) {
                                MediaImage(
                                    mediaRes = preset.resName,
                                    contentDescription = preset.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                if (preset.type == MediaType.VIDEO) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .size(22.dp)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                            .padding(3.dp)
                                    )
                                }
                            }
                            Text(
                                text = preset.title,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Error display
            if (errorMessage != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                ) {
                    Text(
                        text = errorMessage ?: "",
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Title Field
            Text(
                text = "Post Title",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = postTitle,
                onValueChange = {
                    postTitle = it
                    errorMessage = null
                },
                placeholder = { Text("Catchy title for your photo or video...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upload_title_field"),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PulseViolet,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Description / Caption Field
            Text(
                text = "Description & #Hashtags",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = postDescription,
                onValueChange = { postDescription = it },
                placeholder = { Text("Write about your shot, story, gear, location, #tags...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .testTag("upload_description_field"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PulseViolet,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Hashtags Row
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                quickHashtags.forEach { tag ->
                    Surface(
                        onClick = {
                            if (!postDescription.contains(tag)) {
                                postDescription = if (postDescription.isBlank()) tag else "$postDescription $tag"
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = tag,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = PulseViolet,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Category Chips
            Text(
                text = "Category",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Surface(
                        onClick = { selectedCategory = cat },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) PulseCyan.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSelected) BorderStroke(1.5.dp, PulseCyan) else null
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) PulseCyan else MaterialTheme.colorScheme.onSurface,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Location Tag
            Text(
                text = "Location (Optional)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = locationText,
                onValueChange = { locationText = it },
                placeholder = { Text("e.g. Banff National Park, Canada") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = PulsePink
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("upload_location_field"),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PulseViolet,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Location Suggestions
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(quickLocations) { loc ->
                    Surface(
                        onClick = { locationText = loc },
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    ) {
                        Text(
                            text = loc,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // Video Duration slider if video is selected
            if (selectedMediaType == MediaType.VIDEO) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Video Duration",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${videoDurationSeconds}s",
                        color = PulseCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
                Slider(
                    value = videoDurationSeconds.toFloat(),
                    onValueChange = { videoDurationSeconds = it.toInt() },
                    valueRange = 5f..60f,
                    steps = 10,
                    colors = SliderDefaults.colors(
                        thumbColor = PulseCyan,
                        activeTrackColor = PulseCyan,
                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Big Publish Button
            Button(
                onClick = {
                    if (postTitle.isBlank()) {
                        errorMessage = "Please enter a title for your post"
                        return@Button
                    }
                    isPublishing = true
                    errorMessage = null
                    val regex = Regex("#(\\w+)")
                    val foundTags = regex.findAll(postDescription).map { it.groupValues[1] }.toList()

                    onPublish(
                        selectedMediaType,
                        selectedMediaRes,
                        postTitle,
                        postDescription,
                        selectedCategory,
                        foundTags,
                        locationText,
                        if (selectedMediaType == MediaType.VIDEO) videoDurationSeconds else 0
                    )
                },
                enabled = !isPublishing && postTitle.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PulseViolet),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("upload_submit_button")
            ) {
                if (isPublishing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Publish to Feed & Followers",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
