package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.FeedPostUiModel
import com.example.data.model.UserAccount

@Composable
fun PostDetailDialog(
    postUi: FeedPostUiModel?,
    currentUser: UserAccount?,
    onDismiss: () -> Unit,
    onLikeClick: (String) -> Unit,
    onBookmarkClick: (String) -> Unit,
    onCommentClick: (FeedPostUiModel) -> Unit,
    onShareClick: (FeedPostUiModel) -> Unit,
    onFollowClick: (String) -> Unit,
    onAuthorClick: (UserAccount) -> Unit,
    onTagClick: (String) -> Unit
) {
    if (postUi == null) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.88f))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                PostCard(
                    postUi = postUi,
                    isCurrentAuthor = postUi.post.userId == currentUser?.id,
                    onLikeClick = { onLikeClick(postUi.post.id) },
                    onBookmarkClick = { onBookmarkClick(postUi.post.id) },
                    onCommentClick = { onCommentClick(postUi) },
                    onShareClick = { onShareClick(postUi) },
                    onFollowClick = { onFollowClick(postUi.post.userId) },
                    onAuthorClick = {
                        onAuthorClick(postUi.author)
                        onDismiss()
                    },
                    onTagClick = {
                        onTagClick(it)
                        onDismiss()
                    }
                )
            }

            // Top Close Button
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.65f),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_post_detail_dialog")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White
                    )
                }
            }
        }
    }
}
