package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PulseCyan
import com.example.ui.theme.PulsePink
import com.example.ui.theme.PulseViolet
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerView(
    mediaRes: String,
    durationSeconds: Int = 20,
    modifier: Modifier = Modifier,
    onDoubleTap: () -> Unit = {}
) {
    var isPlaying by remember { mutableStateOf(false) }
    var isMuted by remember { mutableStateOf(false) }
    var currentSeconds by remember { mutableIntStateOf(0) }
    var showHeartOverlay by remember { mutableStateOf(false) }
    var showControls by remember { mutableStateOf(true) }

    val safeDuration = if (durationSeconds > 0) durationSeconds else 20

    // Looping playback timer
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying) {
                delay(1000)
                if (currentSeconds >= safeDuration) {
                    currentSeconds = 0
                } else {
                    currentSeconds++
                }
            }
        }
    }

    // Auto-hide play button after starting
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            delay(2000)
            showControls = false
        } else {
            showControls = true
        }
    }

    val progress = (currentSeconds.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    // Infinite transitions for audio equalizer & video motion effect
    val infiniteTransition = rememberInfiniteTransition(label = "videoMotion")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )

    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(550, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b3"
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b4"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        showHeartOverlay = true
                        onDoubleTap()
                    },
                    onTap = {
                        showControls = !showControls
                    }
                )
            }
    ) {
        // Video Poster / Feed Content
        MediaImage(
            mediaRes = mediaRes,
            contentDescription = "Video playback frame",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Video scanline / cinematic overlay when playing
        if (isPlaying) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val lineY = size.height * shimmerOffset
                drawLine(
                    brush = Brush.linearGradient(
                        listOf(
                            Color.Transparent,
                            PulseCyan.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(0f, lineY),
                    end = Offset(size.width, lineY),
                    strokeWidth = 4.dp.toPx()
                )
            }
        }

        // Top Badges (HD Video tag & Audio mute button)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Video pill badge
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Videocam,
                        contentDescription = null,
                        tint = PulseCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPlaying) "PLAYING" else "VIDEO",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Audio Mute toggle
            Surface(
                color = Color.Black.copy(alpha = 0.65f),
                shape = CircleShape,
                modifier = Modifier
                    .size(34.dp)
                    .clickable { isMuted = !isMuted },
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isMuted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp,
                        contentDescription = "Mute audio",
                        tint = if (isMuted) Color.White.copy(alpha = 0.6f) else PulseCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Center Play / Pause Animated Button
        AnimatedVisibility(
            visible = showControls || !isPlaying,
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200)),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .shadow(12.dp, CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                PulseViolet.copy(alpha = 0.9f),
                                Color.Black.copy(alpha = 0.75f)
                            )
                        ),
                        CircleShape
                    )
                    .border(2.dp, Brush.linearGradient(listOf(PulseCyan, PulsePink)), CircleShape)
                    .clickable {
                        isPlaying = !isPlaying
                    }
                    .testTag("video_play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (isPlaying) "Pause video" else "Play video",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Bottom Progress bar & Duration & Equalizer
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Audio Equalizer bars
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.height(18.dp)
                ) {
                    val heights = if (isPlaying && !isMuted) {
                        listOf(bar1, bar2, bar3, bar4)
                    } else {
                        listOf(0.2f, 0.2f, 0.2f, 0.2f)
                    }

                    heights.forEach { h ->
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height((18 * h).dp)
                                .background(
                                    Brush.verticalGradient(listOf(PulsePink, PulseCyan)),
                                    RoundedCornerShape(2.dp)
                                )
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isMuted) "Muted" else "Original Audio",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Time timestamp
                Text(
                    text = String.format("0:%02d / 0:%02d", currentSeconds, safeDuration),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Animated glowing timeline scrubber
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction = progress)
                        .height(4.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(PulseViolet, PulseCyan)
                            ),
                            RoundedCornerShape(2.dp)
                        )
                )
            }
        }

        // Heart animation overlay on double tap
        DoubleTapHeartOverlay(
            show = showHeartOverlay,
            onAnimationEnd = { showHeartOverlay = false }
        )
    }
}
