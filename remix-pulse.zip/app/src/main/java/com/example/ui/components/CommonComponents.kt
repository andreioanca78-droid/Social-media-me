package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.theme.PulseCyan
import com.example.ui.theme.PulsePink
import com.example.ui.theme.PulseViolet
import com.example.ui.theme.PulseVioletDark
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AvatarImage(
    avatarRes: String,
    displayName: String,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    isVerified: Boolean = false,
    showRing: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val initial = displayName.trim().firstOrNull()?.uppercase() ?: "P"
    val avatarGradient = remember(displayName) {
        val hash = kotlin.math.abs(displayName.hashCode())
        val gradients = listOf(
            listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)),
            listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)),
            listOf(Color(0xFFF59E0B), Color(0xFFEF4444)),
            listOf(Color(0xFF10B981), Color(0xFF06B6D4)),
            listOf(Color(0xFF6366F1), Color(0xFFA855F7))
        )
        gradients[hash % gradients.size]
    }

    val context = LocalContext.current
    val drawableId = remember(avatarRes) {
        when (avatarRes) {
            "img_app_icon", "avatar_user" -> R.drawable.img_app_icon
            "img_nature_thumb", "avatar_nature" -> R.drawable.img_nature_thumb
            "img_urban_thumb", "avatar_urban" -> R.drawable.img_urban_thumb
            "img_tech_thumb", "avatar_tech" -> R.drawable.img_tech_thumb
            "avatar_art" -> R.drawable.img_urban_thumb
            else -> {
                val resId = context.resources.getIdentifier(avatarRes, "drawable", context.packageName)
                if (resId != 0) resId else null
            }
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .then(
                if (showRing) {
                    Modifier.border(
                        2.dp,
                        Brush.sweepGradient(listOf(PulseViolet, PulsePink, PulseCyan, PulseViolet)),
                        CircleShape
                    ).padding(2.dp)
                } else Modifier
            )
            .clip(CircleShape)
            .then(
                if (onClick != null) {
                    Modifier.clickable(onClick = onClick)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (avatarRes.startsWith("content://") || avatarRes.startsWith("file://") || avatarRes.startsWith("http")) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(avatarRes)
                    .crossfade(true)
                    .build(),
                contentDescription = "$displayName's avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (drawableId != null) {
            Image(
                painter = painterResource(id = drawableId),
                contentDescription = "$displayName's avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.linearGradient(avatarGradient)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initial,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.45).sp
                )
            }
        }

        if (isVerified) {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = "Verified creator",
                tint = PulseCyan,
                modifier = Modifier
                    .size(size * 0.35f)
                    .align(Alignment.BottomEnd)
                    .background(MaterialTheme.colorScheme.surface, CircleShape)
            )
        }
    }
}

@Composable
fun MediaImage(
    mediaRes: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val context = LocalContext.current
    val drawableId = remember(mediaRes) {
        when (mediaRes) {
            "img_nature_thumb" -> R.drawable.img_nature_thumb
            "img_urban_thumb" -> R.drawable.img_urban_thumb
            "img_tech_thumb" -> R.drawable.img_tech_thumb
            "img_app_icon" -> R.drawable.img_app_icon
            else -> {
                val resId = context.resources.getIdentifier(mediaRes, "drawable", context.packageName)
                if (resId != 0) resId else null
            }
        }
    }

    if (mediaRes.startsWith("content://") || mediaRes.startsWith("file://") || mediaRes.startsWith("http")) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(mediaRes)
                .crossfade(true)
                .build(),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    } else if (drawableId != null) {
        Image(
            painter = painterResource(id = drawableId),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    } else {
        // Fallback stylish gradient canvas
        Box(
            modifier = modifier.background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF1E1B4B),
                        Color(0xFF311042),
                        Color(0xFF0F172A)
                    )
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Outlined.Image,
                    contentDescription = null,
                    tint = PulseCyan.copy(alpha = 0.6f),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Photo Media",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun DoubleTapHeartOverlay(
    show: Boolean,
    onAnimationEnd: () -> Unit
) {
    var visible by remember(show) { mutableStateOf(show) }
    val scale by animateFloatAsState(
        targetValue = if (visible) 1.2f else 0.2f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 400f),
        label = "heartScale"
    )

    LaunchedEffect(show) {
        if (show) {
            visible = true
            kotlinx.coroutines.delay(700)
            visible = false
            onAnimationEnd()
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(),
        exit = fadeOut() + scaleOut()
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Favorite,
                contentDescription = null,
                tint = PulsePink,
                modifier = Modifier
                    .size(90.dp)
                    .scale(scale)
            )
        }
    }
}

fun formatTimeAgo(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        minutes < 1 -> "just now"
        minutes < 60 -> "${minutes}m ago"
        hours < 24 -> "${hours}h ago"
        days < 7 -> "${days}d ago"
        else -> {
            val sdf = SimpleDateFormat("MMM d", Locale.getDefault())
            sdf.format(Date(timestamp))
        }
    }
}

fun formatNumber(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format(Locale.US, "%.1fM", count / 1_000_000.0)
        count >= 10_000 -> String.format(Locale.US, "%.1fk", count / 1000.0)
        count >= 1_000 -> String.format(Locale.US, "%,d", count)
        else -> count.toString()
    }
}
