package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FeedPostUiModel
import com.example.data.model.UserAccount
import com.example.ui.account.AccountSwitchDialog
import com.example.ui.account.CreateAccountDialog
import com.example.ui.components.AvatarImage
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.PostDetailDialog
import com.example.ui.explore.ExploreScreen
import com.example.ui.feed.FeedScreen
import com.example.ui.notifications.NotificationsScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.PulseCyan
import com.example.ui.theme.PulsePink
import com.example.ui.theme.PulseTheme
import com.example.ui.theme.PulseViolet
import com.example.ui.theme.PulseVioletDark
import com.example.ui.upload.UploadScreen
import com.example.ui.viewmodel.NavigationScreen
import com.example.ui.viewmodel.SocialViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: SocialViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PulseTheme {
                PulseApp(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PulseApp(viewModel: SocialViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()

    val activeFeedTab by viewModel.activeFeedTab.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val personalizedFeed by viewModel.personalizedFeed.collectAsState()
    val followingFeed by viewModel.followingFeed.collectAsState()

    val exploreFeed by viewModel.exploreFeed.collectAsState()
    val exploreQuery by viewModel.exploreQuery.collectAsState()

    val selectedProfileUser by viewModel.selectedProfileUser.collectAsState()
    val selectedUserPosts by viewModel.selectedUserPosts.collectAsState()
    val currentUserPosts by viewModel.currentUserPosts.collectAsState()
    val bookmarkedPosts by viewModel.bookmarkedPosts.collectAsState()

    val notifications by viewModel.notifications.collectAsState()
    val unreadNotificationsCount = notifications.count { !it.first.isRead }

    val activeCommentsPost by viewModel.activeCommentsPost.collectAsState()
    val commentsList by viewModel.activePostComments.collectAsState()
    val commentsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val selectedPostDetail by viewModel.selectedPostDetail.collectAsState()
    val showAccountSwitcher by viewModel.showAccountSwitcher.collectAsState()
    val showCreateAccountDialog by viewModel.showCreateAccountDialog.collectAsState()

    fun sharePost(postUi: FeedPostUiModel) {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "Check out \"${postUi.post.title}\" by @${postUi.author.username} on Pulse!\n\n${postUi.post.description}")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share Pulse Media")
        context.startActivity(shareIntent)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Hide bottom bar when uploading
            if (currentScreen != NavigationScreen.CREATE_POST) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .navigationBarsPadding()
                            .height(68.dp)
                    ) {
                        // 1. Feed / Home
                        NavigationBarItem(
                            selected = currentScreen == NavigationScreen.FEED,
                            onClick = { viewModel.navigateTo(NavigationScreen.FEED) },
                            icon = {
                                Icon(
                                    imageVector = if (currentScreen == NavigationScreen.FEED) Icons.Filled.Home else Icons.Outlined.Home,
                                    contentDescription = "Feed",
                                    tint = if (currentScreen == NavigationScreen.FEED) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = "Feed",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentScreen == NavigationScreen.FEED) FontWeight.Bold else FontWeight.Medium,
                                    color = if (currentScreen == NavigationScreen.FEED) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("nav_feed")
                        )

                        // 2. Explore / Search
                        NavigationBarItem(
                            selected = currentScreen == NavigationScreen.EXPLORE,
                            onClick = { viewModel.navigateTo(NavigationScreen.EXPLORE) },
                            icon = {
                                Icon(
                                    imageVector = if (currentScreen == NavigationScreen.EXPLORE) Icons.Filled.Search else Icons.Outlined.Explore,
                                    contentDescription = "Explore",
                                    tint = if (currentScreen == NavigationScreen.EXPLORE) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = "Explore",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentScreen == NavigationScreen.EXPLORE) FontWeight.Bold else FontWeight.Medium,
                                    color = if (currentScreen == NavigationScreen.EXPLORE) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("nav_explore")
                        )

                        // 3. Central Upload FAB
                        NavigationBarItem(
                            selected = false,
                            onClick = { viewModel.navigateTo(NavigationScreen.CREATE_POST) },
                            icon = {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .background(
                                            Brush.linearGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer)),
                                            RoundedCornerShape(16.dp)
                                        )
                                        .shadow(4.dp, RoundedCornerShape(16.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Add,
                                        contentDescription = "Create post",
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.testTag("nav_upload")
                        )

                        // 4. Activity / Notifications
                        NavigationBarItem(
                            selected = currentScreen == NavigationScreen.NOTIFICATIONS,
                            onClick = { viewModel.navigateTo(NavigationScreen.NOTIFICATIONS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (unreadNotificationsCount > 0) {
                                            Badge(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                contentColor = Color.White
                                            ) {
                                                Text(unreadNotificationsCount.toString())
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (currentScreen == NavigationScreen.NOTIFICATIONS) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                                        contentDescription = "Activity",
                                        tint = if (currentScreen == NavigationScreen.NOTIFICATIONS) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = "Activity",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentScreen == NavigationScreen.NOTIFICATIONS) FontWeight.Bold else FontWeight.Medium,
                                    color = if (currentScreen == NavigationScreen.NOTIFICATIONS) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("nav_notifications")
                        )

                        // 5. User Profile
                        NavigationBarItem(
                            selected = currentScreen == NavigationScreen.PROFILE,
                            onClick = { viewModel.navigateTo(NavigationScreen.PROFILE) },
                            icon = {
                                if (currentUser != null) {
                                    AvatarImage(
                                        avatarRes = currentUser!!.avatarRes,
                                        displayName = currentUser!!.displayName,
                                        size = 28.dp,
                                        showRing = currentScreen == NavigationScreen.PROFILE
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Profile"
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = "Profile",
                                    fontSize = 11.sp,
                                    fontWeight = if (currentScreen == NavigationScreen.PROFILE) FontWeight.Bold else FontWeight.Medium,
                                    color = if (currentScreen == NavigationScreen.PROFILE) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("nav_profile")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                label = "screenTransition",
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                }
            ) { screen ->
                when (screen) {
                    NavigationScreen.FEED -> {
                        FeedScreen(
                            currentUser = currentUser,
                            allUsers = allUsers,
                            personalizedFeed = personalizedFeed,
                            followingFeed = followingFeed,
                            activeTab = activeFeedTab,
                            selectedCategory = selectedCategory,
                            onTabSelected = { viewModel.setFeedTab(it) },
                            onCategorySelected = { viewModel.setSelectedCategory(it) },
                            onLikeClick = { viewModel.toggleLike(it) },
                            onBookmarkClick = { viewModel.toggleBookmark(it) },
                            onCommentClick = { viewModel.openComments(it) },
                            onShareClick = { sharePost(it) },
                            onFollowClick = { viewModel.toggleFollow(it) },
                            onAuthorClick = { user -> viewModel.viewUserProfile(user) },
                            onTagClick = { tag ->
                                viewModel.setExploreQuery(tag)
                                viewModel.navigateTo(NavigationScreen.EXPLORE)
                            },
                            onOpenAccountSwitcher = { viewModel.setShowAccountSwitcher(true) },
                            onCreatePostClick = { viewModel.navigateTo(NavigationScreen.CREATE_POST) }
                        )
                    }

                    NavigationScreen.EXPLORE -> {
                        ExploreScreen(
                            explorePosts = exploreFeed,
                            allUsers = allUsers,
                            currentUser = currentUser,
                            searchQuery = exploreQuery,
                            onSearchQueryChange = { viewModel.setExploreQuery(it) },
                            onPostClick = { viewModel.openPostDetail(it) },
                            onAuthorClick = { user -> viewModel.viewUserProfile(user) },
                            onFollowClick = { viewModel.toggleFollow(it) },
                            onTagSelect = { tag -> viewModel.setExploreQuery(tag) }
                        )
                    }

                    NavigationScreen.CREATE_POST -> {
                        UploadScreen(
                            currentUser = currentUser,
                            onPublish = { mediaType, mediaRes, title, description, category, tags, location, videoDuration ->
                                viewModel.uploadPost(
                                    mediaType = mediaType,
                                    mediaRes = mediaRes,
                                    title = title,
                                    description = description,
                                    category = category,
                                    tags = tags,
                                    location = location,
                                    videoDuration = videoDuration,
                                    onSuccess = {
                                        Toast.makeText(context, "Post shared successfully to your followers!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            },
                            onCancel = { viewModel.navigateTo(NavigationScreen.FEED) }
                        )
                    }

                    NavigationScreen.NOTIFICATIONS -> {
                        NotificationsScreen(
                            notifications = notifications,
                            onMarkAllRead = { viewModel.markNotificationsRead() },
                            onUserClick = { user -> viewModel.viewUserProfile(user) }
                        )
                    }

                    NavigationScreen.PROFILE -> {
                        ProfileScreen(
                            user = currentUser,
                            currentUser = currentUser,
                            userPosts = currentUserPosts,
                            bookmarkedPosts = bookmarkedPosts,
                            isFollowing = false,
                            onBackClick = null,
                            onFollowToggle = {},
                            onPostClick = { viewModel.openPostDetail(it) },
                            onOpenAccountSwitcher = { viewModel.setShowAccountSwitcher(true) },
                            onOpenCreateAccount = { viewModel.setShowCreateAccountDialog(true) }
                        )
                    }

                    NavigationScreen.CREATOR_PROFILE -> {
                        val isFollowingCreator = followingFeed.any { it.author.id == selectedProfileUser?.id } ||
                                (currentUser != null && selectedProfileUser != null && selectedProfileUser?.id != currentUser?.id)
                        ProfileScreen(
                            user = selectedProfileUser,
                            currentUser = currentUser,
                            userPosts = selectedUserPosts,
                            bookmarkedPosts = emptyList(),
                            isFollowing = isFollowingCreator,
                            onBackClick = { viewModel.navigateTo(NavigationScreen.FEED) },
                            onFollowToggle = {
                                selectedProfileUser?.let { viewModel.toggleFollow(it.id) }
                            },
                            onPostClick = { viewModel.openPostDetail(it) },
                            onOpenAccountSwitcher = { viewModel.setShowAccountSwitcher(true) },
                            onOpenCreateAccount = { viewModel.setShowCreateAccountDialog(true) }
                        )
                    }
                }
            }
        }
    }

    // Modal: Comments Bottom Sheet
    if (activeCommentsPost != null) {
        CommentsBottomSheet(
            postUi = activeCommentsPost,
            comments = commentsList,
            currentUser = currentUser,
            sheetState = commentsSheetState,
            onDismiss = { viewModel.closeComments() },
            onSendComment = { text ->
                activeCommentsPost?.let { post ->
                    viewModel.addComment(post.post.id, text)
                }
            }
        )
    }

    // Modal: Post Detail View
    if (selectedPostDetail != null) {
        PostDetailDialog(
            postUi = selectedPostDetail,
            currentUser = currentUser,
            onDismiss = { viewModel.closePostDetail() },
            onLikeClick = { viewModel.toggleLike(it) },
            onBookmarkClick = { viewModel.toggleBookmark(it) },
            onCommentClick = {
                viewModel.closePostDetail()
                viewModel.openComments(it)
            },
            onShareClick = { sharePost(it) },
            onFollowClick = { viewModel.toggleFollow(it) },
            onAuthorClick = { user -> viewModel.viewUserProfile(user) },
            onTagClick = { tag ->
                viewModel.setExploreQuery(tag)
                viewModel.navigateTo(NavigationScreen.EXPLORE)
            }
        )
    }

    // Dialog: Account Switcher
    if (showAccountSwitcher) {
        AccountSwitchDialog(
            users = allUsers,
            currentUserId = currentUser?.id,
            onSelectUser = { userId -> viewModel.switchAccount(userId) },
            onCreateNewAccount = {
                viewModel.setShowAccountSwitcher(false)
                viewModel.setShowCreateAccountDialog(true)
            },
            onDismiss = { viewModel.setShowAccountSwitcher(false) }
        )
    }

    // Dialog: Create Account
    if (showCreateAccountDialog) {
        CreateAccountDialog(
            onCreateAccount = { username, displayName, bio, avatarRes, interests ->
                viewModel.createAccount(username, displayName, bio, avatarRes, interests)
                Toast.makeText(context, "Welcome to Pulse, $displayName! Feed personalized.", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { viewModel.setShowCreateAccountDialog(false) }
        )
    }
}
